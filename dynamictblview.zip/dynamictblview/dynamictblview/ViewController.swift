//
//  ViewController.swift
//  dynamictblview
//
//  Created by TOPS on 6/28/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    @IBOutlet weak var tblvw: UITableView!
    
    let arr : [String] = ["SHUNYA by Sri M.","LITTELE THINGS by Dice Media","The 2 Shes: One Gave Me Life Other Became My Life10 by Abhinav Kaushik","The Night of Broken Glass5 by Feroz Rather"];
    
    let img : [String] = ["dwn1.jpg","dwn2.jpg","dwn3.jpg","dwn4.jpg"];
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1;
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count;
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "next", for: indexPath) as! TableViewCell1 ;
        
        cell.lbl.text = arr[indexPath.row];
        
        cell.img.image = UIImage(named: img[indexPath.row]);
        
        cell.btn.addTarget(self, action: #selector(self.test), for: .touchUpInside);
        
        cell.btn.tag = indexPath.row;
        
        return cell;
        
    }
    
    func test(sender: UIButton) {
        
        let idpth = IndexPath(row: sender.tag, section: 0)
        
        let cell = tblvw.cellForRow(at: idpth) as! TableViewCell1
        
        let stb = self.storyboard?.instantiateViewController(withIdentifier: "next") as! ViewController1;
        
        stb.img12 = img[sender.tag];
        
        stb.lbl12 = arr[sender.tag];
        
        self.navigationController?.pushViewController(stb, animated: true);
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

