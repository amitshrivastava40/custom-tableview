//
//  ViewController1.swift
//  dynamictblview
//
//  Created by TOPS on 6/28/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class ViewController1: UIViewController {
    
    var img12 = String();
    
    var lbl12 = String();
    
    @IBOutlet weak var imgvw1: UIImageView!
    
    @IBOutlet weak var lbl1: UILabel!
    
    @IBAction func btn1(_ sender: Any) {
        
        self.navigationController?.popViewController(animated: true)
        
    }
    
    @IBAction func btn2(_ sender: Any) {
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.isNavigationBarHidden = true;
        
        lbl1.text = lbl12;
        
        imgvw1.image = UIImage(named: img12);

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
