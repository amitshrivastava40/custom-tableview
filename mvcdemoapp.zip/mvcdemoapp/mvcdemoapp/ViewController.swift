//
//  ViewController.swift
//  mvcdemoapp
//
//  Created by TOPS on 8/4/18.
//  Copyright © 2018 abhishek. All rights reserved.
//

import UIKit

class ViewController: UIViewController,EmployeeDelegate {

    @IBOutlet weak var img: UIImageView!
    
    @IBOutlet weak var txtempid: UITextField!
   
    @IBOutlet weak var txtempname: UITextField!
    
    @IBOutlet weak var txtempadd: UITextField!
    
    @IBOutlet weak var txtempmob: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    @IBAction func buttonclick(_ sender: Any) {
        
        let imgdata = UIImageJPEGRepresentation(img.image!, 0.2)
        
        let base64data = imgdata?.base64EncodedString(options: Data.Base64EncodingOptions.lineLength64Characters);
        
        let obj = employee(empid: 0, empname: txtempname.text!, empadd: txtempadd.text!, empmob: txtempmob.text!, empimg: base64data!)
        
        let objcnt = employee_controller();
        
        objcnt.delegate = self;
        
        objcnt.InsertEmployeeData(obj: obj);
        
   
        
    }
    
    func ReturnValue(stt: String)  {
        print(stt);
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

