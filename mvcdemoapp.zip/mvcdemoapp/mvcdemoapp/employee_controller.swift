//
//  employee_controller.swift
//  mvcdemoapp
//
//  Created by TOPS on 8/4/18.
//  Copyright © 2018 abhishek. All rights reserved.
//

import UIKit

protocol EmployeeDelegate {
    
    func ReturnValue(stt: String);
    
}

class employee_controller: NSObject {

    var delegate : EmployeeDelegate?
    
    func InsertEmployeeData(obj: employee) {
        
        let url = URL(string: "http://localhost/iosbatch/imageindex.php")
        
        let dic = ["empname": obj.empname!,
                    "empadd": obj.empadd!,
                    "empmob": obj.empmob!,
                    "empimg": obj.empimg!]
        
        do {
            let finalbody = try JSONSerialization.data(withJSONObject: dic, options: []);
            
            var request = URLRequest(url: url!)
            
            request.addValue(String(finalbody.count), forHTTPHeaderField: "Content-length");
            
            request.httpBody = finalbody;
            
            request.httpMethod = "POST";
            
            let session = URLSession.shared;
            
            let datatask = session.dataTask(with: request) {
                (data1,rsp,err) in
                
                if err == nil
                {
                    let strrsp = String(data: data1!, encoding: String.Encoding.utf8);
                    
                    DispatchQueue.main.async {
                        self.delegate?.ReturnValue(stt: strrsp!)
                    }
                }
            }
            
            datatask.resume();
            
            
        } catch  {
            
        }
 
    }
    
    
}
